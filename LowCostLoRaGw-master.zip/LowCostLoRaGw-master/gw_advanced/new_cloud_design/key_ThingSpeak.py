# LoRa test channel
_def_thingspeak_channel_key='SGSH52UGPVAUYG3S'